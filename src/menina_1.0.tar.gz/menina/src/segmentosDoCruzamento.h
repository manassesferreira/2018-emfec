bool segmentosDoCruzamento(int g, int xCruz, int yCruz, int *N, int *L, int *O, int *S, int *borda);
